//
//  DismissTableViewCell.swift
//  cs212_RPShistory_rebuild
//
//  Created by Lucas Ruprecht on 4/5/16.
//  Copyright © 2016 Lucas Ruprecht. All rights reserved.
//

import UIKit

class DismissTableViewCell: UITableViewCell {
    
    @IBOutlet weak var button: UIButton!
    
    
}
