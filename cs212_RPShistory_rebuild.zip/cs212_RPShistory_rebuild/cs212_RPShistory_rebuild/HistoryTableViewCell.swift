//
//  HistoryTableViewCell.swift
//  cs212_Homework6_RockPaperScissors
//
//  Created by Lucas Ruprecht on 3/28/16.
//  Copyright © 2016 Lucas Ruprecht. All rights reserved.
//

import UIKit

class HistoryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var matchLabel: UILabel!
    
}
