//
//  RPSMatch.swift
//  cs212_Homework6_RockPaperScissors
//
//  Created by Lucas Ruprecht on 3/25/16.
//  Copyright © 2016 Lucas Ruprecht. All rights reserved.
//

import UIKit

class RPSMatch: NSObject {
    var value: String!
    init(string: String) {
        self.value = string
    }
}
